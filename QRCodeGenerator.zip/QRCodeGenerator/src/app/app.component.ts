import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'QRCodeGenerator';
  QRdata: any;
  constructor(){
    this.QRdata= "https://www.linkedin.com/in/rohitha-gourabathuni-47573b161/";
  }

 

}
